
package ParkingManagementSystem;

import javax.swing.JOptionPane;

public class PaymentSystem extends Drivers
{
    private static int cost = 0;
    private static int amount = 0;
    private static int leftBalance = 0;
    private static String conformation = "";
    
    Drivers pay = new Drivers();
    
    PaymentSystem()
    {
        checkIdN();
        leftAmount();
    }
    
     public void checkIdN()
    {
//        JOptionPane.showMessageDialog(null, "Are you sure your id number is " + pay.getId(), "CHECK", JOptionPane.WARNING_MESSAGE);
        conformation = JOptionPane.showInputDialog("Are you sure your id number is " + pay.getIdNum() + "\nTYPE YES/yes if true","Conformation");      
        if(conformation.equalsIgnoreCase("yes"))
        {
            recharge();
        }        
    }//end of check id
     
    public void recharge()
    {
        String amountStr = JOptionPane.showInputDialog("Enter your amount to recharge.","PAYMENT"); 
        amount = Integer.parseInt(amountStr); 
        int tAmount = amount + leftBalance;
        JOptionPane.showMessageDialog(null, "Your total balance is " + tAmount, "Total Amount", JOptionPane.WARNING_MESSAGE);
    }//end of recharge
     
    public void leftAmount()
    {
        leftBalance = amount - 2;
//        JOptionPane.showMessageDialog(null, "Left Amount " + getLeftBalance(), "AMOUNT", JOptionPane.WARNING_MESSAGE);
    }
    
    public int getAmount()
    {
      return amount;  
    }
    
    public void setAmount(int newAmount)
    {
      newAmount = amount;  
    }
    
    public int getLeftBalance()
    {
      return leftBalance;  
    }
    
    public void setLeftBalance(int newLeftBalance)
    {
      newLeftBalance = leftBalance;  
    }

}//end of class
